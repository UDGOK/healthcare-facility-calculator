exports.id=290,exports.ids=[290],exports.modules={9362:(e,t,s)=>{"use strict";s.d(t,{A:()=>a});let a=(0,s(19377).A)("CheckCircle",[["path",{d:"M22 11.08V12a10 10 0 1 1-5.93-9.14",key:"g774vq"}],["polyline",{points:"22 4 12 14.01 9 11.01",key:"6xbx8j"}]])},19377:(e,t,s)=>{"use strict";s.d(t,{A:()=>l});var a=s(43210),i={xmlns:"http://www.w3.org/2000/svg",width:24,height:24,viewBox:"0 0 24 24",fill:"none",stroke:"currentColor",strokeWidth:2,strokeLinecap:"round",strokeLinejoin:"round"};let r=e=>e.replace(/([a-z0-9])([A-Z])/g,"$1-$2").toLowerCase();var l=(e,t)=>{let s=(0,a.forwardRef)(({color:s="currentColor",size:l=24,strokeWidth:o=2,absoluteStrokeWidth:n,children:d,...c},m)=>(0,a.createElement)("svg",{ref:m,...i,width:l,height:l,stroke:s,strokeWidth:n?24*Number(o)/Number(l):o,className:`lucide lucide-${r(e)}`,...c},[...t.map(([e,t])=>(0,a.createElement)(e,t)),...(Array.isArray(d)?d:[d])||[]]));return s.displayName=`${e}`,s}},29131:(e,t,s)=>{"use strict";s.d(t,{AuthProvider:()=>i});var a=s(12907);(0,a.registerClientReference)(function(){throw Error("Attempted to call useAuth() from the server but useAuth is on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.")},"/home/project/oral2/oral-surgeon-costimator/src/contexts/AuthContext.tsx","useAuth");let i=(0,a.registerClientReference)(function(){throw Error("Attempted to call AuthProvider() from the server but AuthProvider is on the client. It's not possible to invoke a client function from the server, it can only be rendered as a Component or passed to props of a Client Component.")},"/home/project/oral2/oral-surgeon-costimator/src/contexts/AuthContext.tsx","AuthProvider")},29446:(e,t,s)=>{"use strict";s.d(t,{A:()=>a});let a=(0,s(19377).A)("User",[["path",{d:"M19 21v-2a4 4 0 0 0-4-4H9a4 4 0 0 0-4 4v2",key:"975kel"}],["circle",{cx:"12",cy:"7",r:"4",key:"17ys0d"}]])},30444:(e,t,s)=>{"use strict";s.d(t,{A:()=>a});let a=(0,s(19377).A)("Wrench",[["path",{d:"M14.7 6.3a1 1 0 0 0 0 1.4l1.6 1.6a1 1 0 0 0 1.4 0l3.77-3.77a6 6 0 0 1-7.94 7.94l-6.91 6.91a2.12 2.12 0 0 1-3-3l6.91-6.91a6 6 0 0 1 7.94-7.94l-3.76 3.76z",key:"cbrjhi"}]])},37775:(e,t,s)=>{"use strict";s.d(t,{A:()=>a});let a=(0,s(19377).A)("ArrowRight",[["path",{d:"M5 12h14",key:"1ays0h"}],["path",{d:"m12 5 7 7-7 7",key:"xquz4c"}]])},38444:(e,t,s)=>{Promise.resolve().then(s.bind(s,63213))},39364:(e,t,s)=>{Promise.resolve().then(s.t.bind(s,86346,23)),Promise.resolve().then(s.t.bind(s,27924,23)),Promise.resolve().then(s.t.bind(s,35656,23)),Promise.resolve().then(s.t.bind(s,40099,23)),Promise.resolve().then(s.t.bind(s,38243,23)),Promise.resolve().then(s.t.bind(s,28827,23)),Promise.resolve().then(s.t.bind(s,62763,23)),Promise.resolve().then(s.t.bind(s,97173,23))},51596:(e,t,s)=>{Promise.resolve().then(s.bind(s,29131))},53106:(e,t,s)=>{"use strict";s.d(t,{A:()=>a});let a=(0,s(19377).A)("Mail",[["rect",{width:"20",height:"16",x:"2",y:"4",rx:"2",key:"18n3k1"}],["path",{d:"m22 7-8.97 5.7a1.94 1.94 0 0 1-2.06 0L2 7",key:"1ocrg3"}]])},61135:()=>{},63213:(e,t,s)=>{"use strict";s.d(t,{A:()=>l,AuthProvider:()=>o});var a=s(76392),i=s(43210);let r=(0,i.createContext)(void 0),l=()=>{let e=(0,i.useContext)(r);if(void 0===e)throw Error("useAuth must be used within an AuthProvider");return e},o=({children:e})=>{let[t,s]=(0,i.useState)(null),[l,o]=(0,i.useState)(!0);(0,i.useEffect)(()=>{o(!1)},[]);let n=async(e,t)=>{o(!0);let a=JSON.parse(localStorage.getItem("ds-arch-users")||"[]").find(s=>s.email===e&&s.password===t);if(a){let{password:e,...t}=a;return s(t),localStorage.setItem("ds-arch-user",JSON.stringify(t)),o(!1),!0}return o(!1),!1},d=async(e,t,a)=>{o(!0);let i=JSON.parse(localStorage.getItem("ds-arch-users")||"[]");if(i.find(t=>t.email===e))return o(!1),!1;let r={id:Math.random().toString(36).substr(2,9),email:e,password:t,name:a,role:"admin@dsarch.org"===e?"admin":"user",createdAt:new Date().toISOString(),estimates:[]};i.push(r),localStorage.setItem("ds-arch-users",JSON.stringify(i));let{password:l,...n}=r;return s(n),localStorage.setItem("ds-arch-user",JSON.stringify(n)),o(!1),!0};return(0,a.jsx)(r.Provider,{value:{user:t,login:n,signup:d,logout:()=>{s(null),localStorage.removeItem("ds-arch-user")},isLoading:l,saveEstimate:(e,a)=>{if(!t)return;let i=JSON.parse(localStorage.getItem("ds-arch-estimates")||"{}");i[e]={...a,id:e,userId:t.id,savedAt:new Date().toISOString()},localStorage.setItem("ds-arch-estimates",JSON.stringify(i));let r=JSON.parse(localStorage.getItem("ds-arch-users")||"[]"),l=r.findIndex(e=>e.id===t.id);-1===l||r[l].estimates.includes(e)||(r[l].estimates.push(e),localStorage.setItem("ds-arch-users",JSON.stringify(r))),s(t=>t?{...t,estimates:t.estimates.includes(e)?t.estimates:[...t.estimates,e]}:null)},getUserEstimates:()=>{if(!t)return[];let e=JSON.parse(localStorage.getItem("ds-arch-estimates")||"{}");return t.estimates.map(t=>e[t]).filter(Boolean)},deleteEstimate:e=>{if(!t)return;let a=JSON.parse(localStorage.getItem("ds-arch-estimates")||"{}");delete a[e],localStorage.setItem("ds-arch-estimates",JSON.stringify(a));let i=JSON.parse(localStorage.getItem("ds-arch-users")||"[]"),r=i.findIndex(e=>e.id===t.id);-1!==r&&(i[r].estimates=i[r].estimates.filter(t=>t!==e),localStorage.setItem("ds-arch-users",JSON.stringify(i))),s(t=>t?{...t,estimates:t.estimates.filter(t=>t!==e)}:null)}},children:e})}},77473:(e,t,s)=>{"use strict";s.d(t,{A:()=>a});let a=(0,s(19377).A)("X",[["path",{d:"M18 6 6 18",key:"1bl5f8"}],["path",{d:"m6 6 12 12",key:"d8bk6v"}]])},78520:(e,t,s)=>{"use strict";s.d(t,{A:()=>a});let a=(0,s(19377).A)("AlertCircle",[["circle",{cx:"12",cy:"12",r:"10",key:"1mglay"}],["line",{x1:"12",x2:"12",y1:"8",y2:"12",key:"1pkeuh"}],["line",{x1:"12",x2:"12.01",y1:"16",y2:"16",key:"4dfq90"}]])},86212:(e,t,s)=>{Promise.resolve().then(s.t.bind(s,16444,23)),Promise.resolve().then(s.t.bind(s,16042,23)),Promise.resolve().then(s.t.bind(s,88170,23)),Promise.resolve().then(s.t.bind(s,49477,23)),Promise.resolve().then(s.t.bind(s,29345,23)),Promise.resolve().then(s.t.bind(s,12089,23)),Promise.resolve().then(s.t.bind(s,46577,23)),Promise.resolve().then(s.t.bind(s,31307,23))},94431:(e,t,s)=>{"use strict";s.r(t),s.d(t,{default:()=>c,metadata:()=>d});var a=s(1110),i=s(2202),r=s.n(i),l=s(64988),o=s.n(l);s(61135);var n=s(29131);let d={title:"DS Arch Medical Cost Estimator",description:"Professional facility cost estimation for dsarch.org"};function c({children:e}){return(0,a.jsx)("html",{lang:"en",children:(0,a.jsx)("body",{className:`${r().variable} ${o().variable} antialiased`,children:(0,a.jsx)(n.AuthProvider,{children:e})})})}},97152:(e,t,s)=>{"use strict";s.d(t,{A:()=>a});let a=(0,s(19377).A)("Save",[["path",{d:"M19 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h11l5 5v11a2 2 0 0 1-2 2z",key:"1owoqh"}],["polyline",{points:"17 21 17 13 7 13 7 21",key:"1md35c"}],["polyline",{points:"7 3 7 8 15 8",key:"8nz8an"}]])},98316:(e,t,s)=>{"use strict";s.d(t,{A:()=>p});var a=s(76392),i=s(43210),r=s(63213);class l{constructor(){this.apiKey=null,this.baseUrl="https://api.emailservice.com",this.apiKey=process.env.NEXT_PUBLIC_EMAIL_API_KEY||null}async sendEstimateEmail(e){try{await new Promise(e=>setTimeout(e,1500));let t=this.generateEstimateEmailTemplate(e);if(!this.isValidEmail(e.clientEmail))return{success:!1,message:"Invalid email address provided"};{let s=JSON.parse(localStorage.getItem("ds-arch-sent-emails")||"[]");return s.push({id:Math.random().toString(36).substr(2,9),to:e.clientEmail,subject:t.subject,sentAt:new Date().toISOString(),status:"sent",projectName:e.projectName,senderName:e.senderName}),localStorage.setItem("ds-arch-sent-emails",JSON.stringify(s)),{success:!0,message:`Estimate successfully sent to ${e.clientEmail}`}}}catch(e){return console.error("Email sending failed:",e),{success:!1,message:"Failed to send email. Please try again later."}}}async sendNotificationEmail(e,t,s){try{if(await new Promise(e=>setTimeout(e,1e3)),!this.isValidEmail(e))return{success:!1,message:"Invalid email address"};{let s=JSON.parse(localStorage.getItem("ds-arch-sent-emails")||"[]");return s.push({id:Math.random().toString(36).substr(2,9),to:e,subject:t,sentAt:new Date().toISOString(),status:"sent",type:"notification"}),localStorage.setItem("ds-arch-sent-emails",JSON.stringify(s)),{success:!0,message:`Notification sent to ${e}`}}}catch(e){return{success:!1,message:"Failed to send notification"}}}generateEstimateEmailTemplate(e){let t=`
      <!DOCTYPE html>
      <html lang="en">
      <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Medical Facility Cost Estimate</title>
        <style>
          body {
            font-family: Arial, sans-serif;
            line-height: 1.6;
            color: #333;
            max-width: 600px;
            margin: 0 auto;
            padding: 20px;
          }
          .header {
            background: linear-gradient(135deg, #2563eb, #1d4ed8);
            color: white;
            padding: 30px;
            border-radius: 10px;
            text-align: center;
            margin-bottom: 30px;
          }
          .content {
            background: #f8fafc;
            padding: 30px;
            border-radius: 10px;
            margin-bottom: 30px;
          }
          .estimate-summary {
            background: white;
            border: 1px solid #e2e8f0;
            border-radius: 8px;
            padding: 20px;
            margin: 20px 0;
          }
          .total-cost {
            font-size: 28px;
            font-weight: bold;
            color: #2563eb;
            text-align: center;
            padding: 20px;
            background: #eff6ff;
            border-radius: 8px;
            margin: 20px 0;
          }
          .button {
            display: inline-block;
            background: #2563eb;
            color: white;
            padding: 12px 24px;
            text-decoration: none;
            border-radius: 6px;
            font-weight: bold;
            margin: 10px 0;
          }
          .footer {
            text-align: center;
            color: #6b7280;
            font-size: 14px;
            margin-top: 30px;
            padding-top: 20px;
            border-top: 1px solid #e2e8f0;
          }
          .project-details {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 15px;
            margin: 20px 0;
          }
          .detail-item {
            padding: 10px;
            background: #f1f5f9;
            border-radius: 6px;
          }
          .detail-label {
            font-weight: bold;
            color: #475569;
            font-size: 12px;
            text-transform: uppercase;
            margin-bottom: 5px;
          }
          .detail-value {
            color: #1e293b;
            font-size: 14px;
          }
        </style>
      </head>
      <body>
        <div class="header">
          <h1>Medical Facility Cost Estimate</h1>
          <p>Professional facility estimation from DS Arch</p>
        </div>

        <div class="content">
          <h2>Dear ${e.clientName},</h2>

          <p>Thank you for your interest in our medical facility cost estimation services. We've prepared a comprehensive estimate for your project.</p>

          <div class="estimate-summary">
            <h3>Project Summary</h3>

            <div class="project-details">
              <div class="detail-item">
                <div class="detail-label">Project Name</div>
                <div class="detail-value">${e.projectName}</div>
              </div>
              <div class="detail-item">
                <div class="detail-label">Facility Type</div>
                <div class="detail-value">${e.facilityType}</div>
              </div>
            </div>

            <div class="total-cost">
              Total Project Cost: $${e.totalCost.toLocaleString()}
            </div>

            <p style="text-align: center;">
              <a href="${e.estimateUrl}" class="button">View Detailed Estimate</a>
            </p>
          </div>

          <h3>What's Included</h3>
          <ul>
            <li>Complete equipment and materials pricing</li>
            <li>Professional installation and labor costs</li>
            <li>Medical gas systems configuration</li>
            <li>NFPA 99 and regulatory compliance</li>
            <li>10% project contingency</li>
          </ul>

          <h3>Next Steps</h3>
          <p>This estimate is valid for 30 days. To proceed with your project or discuss any modifications, please contact us at your earliest convenience.</p>

          <p>We look forward to working with you on this important project.</p>

          <p>Best regards,<br>
          <strong>${e.senderName}</strong><br>
          ${e.senderEmail}<br>
          DS Arch Medical Cost Estimator</p>
        </div>

        <div class="footer">
          <p>This estimate was generated by DS Arch Medical Cost Estimator</p>
          <p>Visit <a href="https://dsarch.org" style="color: #2563eb;">dsarch.org</a> for more information</p>
        </div>
      </body>
      </html>
    `;return{to:e.clientEmail,subject:`Medical Facility Cost Estimate - ${e.projectName}`,htmlContent:t}}isValidEmail(e){return/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(e)}getSentEmails(){return JSON.parse(localStorage.getItem("ds-arch-sent-emails")||"[]")}getEmailAnalytics(){let e=this.getSentEmails(),t=new Date,s=new Date(t.getTime()-6048e5),a=new Date(t.getTime()-2592e6);return{totalSent:e.length,sentThisWeek:e.filter(e=>new Date(e.sentAt)>=s).length,sentThisMonth:e.filter(e=>new Date(e.sentAt)>=a).length,recentEmails:e.slice(-10).reverse()}}}let o=new l;var n=s(53106),d=s(77473),c=s(9235),m=s(9362),u=s(78520),h=s(29446);let g=(0,s(19377).A)("Send",[["path",{d:"m22 2-7 20-4-9-9-4Z",key:"1q3vgg"}],["path",{d:"M22 2 11 13",key:"nzbqef"}]]);function p({estimate:e,isOpen:t,onClose:s,onSuccess:l}){let{user:p}=(0,r.A)(),[x,y]=(0,i.useState)({clientEmail:"",clientName:e.clientName||"",customMessage:""}),[b,f]=(0,i.useState)(!1),[v,N]=(0,i.useState)({type:null,message:""}),j=async t=>{if(t.preventDefault(),!p)return void N({type:"error",message:"You must be logged in to send emails"});if(!x.clientEmail||!x.clientName)return void N({type:"error",message:"Please fill in all required fields"});f(!0),N({type:null,message:""});try{let t=`${window.location.origin}/estimate/view?id=${e.id}`,a={clientEmail:x.clientEmail,clientName:x.clientName,projectName:e.projectName,facilityType:e.facilityType,totalCost:e.totalCost,estimateUrl:t,senderName:p.name,senderEmail:p.email},i=await o.sendEstimateEmail(a);if(i.success){N({type:"success",message:i.message});let t=JSON.parse(localStorage.getItem("ds-arch-estimates")||"{}");t[e.id]&&(t[e.id].emailHistory=t[e.id].emailHistory||[],t[e.id].emailHistory.push({sentTo:x.clientEmail,sentAt:new Date().toISOString(),sentBy:p.name}),t[e.id].status="sent",localStorage.setItem("ds-arch-estimates",JSON.stringify(t))),l&&setTimeout(()=>{l(),s()},2e3)}else N({type:"error",message:i.message})}catch(e){N({type:"error",message:"Failed to send email. Please try again."})}finally{f(!1)}};return t?(0,a.jsx)("div",{className:"fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4",children:(0,a.jsxs)("div",{className:"bg-white rounded-xl shadow-2xl max-w-2xl w-full max-h-[90vh] overflow-y-auto",children:[(0,a.jsxs)("div",{className:"flex items-center justify-between p-6 border-b border-gray-200",children:[(0,a.jsxs)("div",{className:"flex items-center space-x-3",children:[(0,a.jsx)("div",{className:"bg-blue-100 p-2 rounded-lg",children:(0,a.jsx)(n.A,{className:"h-6 w-6 text-blue-600"})}),(0,a.jsxs)("div",{children:[(0,a.jsx)("h2",{className:"text-xl font-bold text-gray-900",children:"Send Estimate via Email"}),(0,a.jsx)("p",{className:"text-sm text-gray-600",children:"Share your estimate with the client"})]})]}),(0,a.jsx)("button",{onClick:s,className:"p-2 text-gray-400 hover:text-gray-600 rounded-lg hover:bg-gray-100",children:(0,a.jsx)(d.A,{className:"h-5 w-5"})})]}),(0,a.jsxs)("div",{className:"p-6 bg-gray-50 border-b border-gray-200",children:[(0,a.jsx)("h3",{className:"text-lg font-semibold text-gray-900 mb-4",children:"Estimate Summary"}),(0,a.jsxs)("div",{className:"grid md:grid-cols-2 gap-4",children:[(0,a.jsxs)("div",{className:"flex items-center space-x-3",children:[(0,a.jsx)(c.A,{className:"h-5 w-5 text-gray-400"}),(0,a.jsxs)("div",{children:[(0,a.jsx)("div",{className:"text-sm font-medium text-gray-900",children:e.projectName}),(0,a.jsx)("div",{className:"text-xs text-gray-600",children:e.facilityType})]})]}),(0,a.jsxs)("div",{className:"text-right",children:[(0,a.jsxs)("div",{className:"text-2xl font-bold text-blue-600",children:["$",e.totalCost.toLocaleString()]}),(0,a.jsx)("div",{className:"text-xs text-gray-600",children:"Total Project Cost"})]})]})]}),(0,a.jsxs)("form",{onSubmit:j,className:"p-6 space-y-6",children:[v.type&&(0,a.jsxs)("div",{className:`p-4 rounded-lg flex items-center space-x-3 ${"success"===v.type?"bg-green-50 border border-green-200":"bg-red-50 border border-red-200"}`,children:["success"===v.type?(0,a.jsx)(m.A,{className:"h-5 w-5 text-green-500"}):(0,a.jsx)(u.A,{className:"h-5 w-5 text-red-500"}),(0,a.jsx)("span",{className:`text-sm font-medium ${"success"===v.type?"text-green-800":"text-red-800"}`,children:v.message})]}),(0,a.jsxs)("div",{className:"space-y-4",children:[(0,a.jsx)("h4",{className:"text-lg font-semibold text-gray-900",children:"Client Information"}),(0,a.jsxs)("div",{className:"grid md:grid-cols-2 gap-4",children:[(0,a.jsxs)("div",{children:[(0,a.jsx)("label",{htmlFor:"clientName",className:"block text-sm font-medium text-gray-700 mb-2",children:"Client Name *"}),(0,a.jsxs)("div",{className:"relative",children:[(0,a.jsx)("div",{className:"absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none",children:(0,a.jsx)(h.A,{className:"h-5 w-5 text-gray-400"})}),(0,a.jsx)("input",{id:"clientName",type:"text",value:x.clientName,onChange:e=>y({...x,clientName:e.target.value}),className:"w-full pl-10 pr-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 text-gray-900",placeholder:"Enter client name",required:!0})]})]}),(0,a.jsxs)("div",{children:[(0,a.jsx)("label",{htmlFor:"clientEmail",className:"block text-sm font-medium text-gray-700 mb-2",children:"Client Email *"}),(0,a.jsxs)("div",{className:"relative",children:[(0,a.jsx)("div",{className:"absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none",children:(0,a.jsx)(n.A,{className:"h-5 w-5 text-gray-400"})}),(0,a.jsx)("input",{id:"clientEmail",type:"email",value:x.clientEmail,onChange:e=>y({...x,clientEmail:e.target.value}),className:"w-full pl-10 pr-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 text-gray-900",placeholder:"client@example.com",required:!0})]})]})]})]}),(0,a.jsxs)("div",{children:[(0,a.jsx)("label",{htmlFor:"customMessage",className:"block text-sm font-medium text-gray-700 mb-2",children:"Custom Message (Optional)"}),(0,a.jsx)("textarea",{id:"customMessage",value:x.customMessage,onChange:e=>y({...x,customMessage:e.target.value}),rows:4,className:"w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 text-gray-900",placeholder:"Add a personal message to include with the estimate..."})]}),(0,a.jsxs)("div",{className:"bg-gray-50 rounded-lg p-4",children:[(0,a.jsx)("h5",{className:"text-sm font-semibold text-gray-900 mb-3",children:"Email Preview"}),(0,a.jsxs)("div",{className:"text-sm text-gray-600 space-y-2",children:[(0,a.jsxs)("div",{children:[(0,a.jsx)("strong",{children:"To:"})," ",x.clientEmail||"client@example.com"]}),(0,a.jsxs)("div",{children:[(0,a.jsx)("strong",{children:"Subject:"})," Medical Facility Cost Estimate - ",e.projectName]}),(0,a.jsxs)("div",{className:"bg-white rounded p-3 border border-gray-200",children:[(0,a.jsxs)("p",{children:["Dear ",x.clientName||"[Client Name]",","]}),(0,a.jsxs)("p",{className:"mt-2",children:["Thank you for your interest in our medical facility cost estimation services. We've prepared a comprehensive estimate for your ",e.facilityType.toLowerCase()," project."]}),x.customMessage&&(0,a.jsx)("div",{className:"mt-3 p-3 bg-blue-50 rounded border-l-4 border-blue-400",children:(0,a.jsx)("p",{className:"italic",children:x.customMessage})}),(0,a.jsx)("p",{className:"mt-2",children:"The email will include a link to view the detailed estimate online."})]})]})]}),(0,a.jsxs)("div",{className:"flex justify-between items-center pt-4 border-t border-gray-200",children:[(0,a.jsx)("button",{type:"button",onClick:()=>{y({clientEmail:"",clientName:e.clientName||"",customMessage:""}),N({type:null,message:""})},className:"text-gray-600 hover:text-gray-800 text-sm font-medium",children:"Reset Form"}),(0,a.jsxs)("div",{className:"flex space-x-3",children:[(0,a.jsx)("button",{type:"button",onClick:s,className:"px-6 py-3 border border-gray-300 text-gray-700 rounded-lg hover:bg-gray-50 font-medium",children:"Cancel"}),(0,a.jsxs)("button",{type:"submit",disabled:b||!x.clientEmail||!x.clientName,className:"px-6 py-3 bg-blue-600 text-white rounded-lg hover:bg-blue-700 disabled:opacity-50 disabled:cursor-not-allowed flex items-center space-x-2 font-medium",children:[b?(0,a.jsx)("div",{className:"animate-spin rounded-full h-5 w-5 border-b-2 border-white"}):(0,a.jsx)(g,{className:"h-5 w-5"}),(0,a.jsx)("span",{children:b?"Sending...":"Send Estimate"})]})]})]})]})]})}):null}}};